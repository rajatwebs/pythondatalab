POSTGRESQL_CONFIG = {
    'host': 'localhost',
    'port': '5433',
    'dbname': 'ecommerce_db',
    'user': 'postgres',
    'password': 'postgres'
}

MYSQL_CONFIG = {
    'host': 'localhost',
    'port': '3306',
    'dbname': 'data_warehouse',
    'user': 'mysql',
    'password': 'mysql'
}
