## 06: SQL & NoSQL Databases with Python
**Working with SQL Databases**
- Introduction to SQL and relational databases
- SQL basics (SELECT, FROM, WHERE, JOIN)
- Creating and managing databases, tables, and indexes
- CRUD operations (Create, Read, Update, Delete)
- Connecting to databases
- Executing SQL queries
- Fetching and manipulating data with SQL
- Using SQLAlchemy for database interaction

**Working with NoSQL Databases**
- Understanding NoSQL databases (e.g., MongoDB, Redis)
- Connecting to NoSQL databases
- Querying and manipulating data in NoSQL databases
- Handling document-based and key-value data models

**Assignment:** Ass6